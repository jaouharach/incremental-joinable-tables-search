rm  Makefile Makefile.in aclocal.m4	compile	config.log	config.status	configure	depcomp	install-sh	missing	src/config.h.in	src/stamp-h1
rm -rf autom4te.cache/
